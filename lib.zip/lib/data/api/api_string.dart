class ApiString {
  static const String baseUrl = "https://dummyjson.com/";
  static const String login = "auth/login";
  static const String auth = "auth/me";
  static const String refresh = "auth/refresh";
}
