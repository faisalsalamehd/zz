import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:zz/data/models/login/login_screen_model.dart';
import 'package:http/http.dart' as http;

class LoginController extends GetxController {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String name = 'Zain';
  String email = 'zain@example.com';
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  LoginScreenModel loginModel = LoginScreenModel(username: '', password: '');

  void login() async {
    if (!formKey.currentState!.validate()) {
      return;
    }
    loginModel.username = usernameController.text;
    loginModel.password = passwordController.text;


  }
}
