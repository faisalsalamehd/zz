class RoutesStrings {
  static const String splash = "/";
  static const String home = "/home";
  static const String view1 = "/view1";
  static const String view2 = "/view2";
  static const String view3 = "/view3";
  static const String welcome = "/welcome";
  static const String register = "/register";
  static const String login = "/login";
  static const String forgotPassword = "/forgotPassword";
  static const String newPassword = "/newPassword";
}
